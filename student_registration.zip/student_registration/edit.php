<?php
include('db.php');
$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM students WHERE id=$id");
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Student</title>
</head>
<body>
  <h2>Edit Student</h2>
  <form method="POST">
    <input type="text" name="name" value="<?php echo $row['name']; ?>" required><br><br>
    <input type="email" name="email" value="<?php echo $row['email']; ?>" required><br><br>
    <input type="text" name="phone" value="<?php echo $row['phone']; ?>" required><br><br>
    <input type="text" name="course" value="<?php echo $row['course']; ?>" required><br><br>
    <button type="submit" name="update">Update</button>
  </form>

  <?php
  if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];

    $sql = "UPDATE students SET name='$name', email='$email', phone='$phone', course='$course' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
      echo "<p style='color:green;'>Student updated successfully!</p>";
    } else {
      echo "<p style='color:red;'>Error: " . mysqli_error($conn) . "</p>";
    }
  }
  ?>
  <br><a href="index.php">← Back to Home</a>
</body>
</html>