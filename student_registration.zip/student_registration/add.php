<?php include('db.php'); ?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Student</title>
</head>
<body>
  <h2>Add New Student</h2>
  <form method="POST">
    <input type="text" name="name" placeholder="Full Name" required><br><br>
    <input type="email" name="email" placeholder="Email Address" required><br><br>
    <input type="text" name="phone" placeholder="Phone Number" required><br><br>
    <input type="text" name="course" placeholder="Course" required><br><br>
    <button type="submit" name="submit">Save Student</button>
  </form>

  <?php
  if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];

    $sql = "INSERT INTO students (name, email, phone, course) VALUES ('$name', '$email', '$phone', '$course')";
    if (mysqli_query($conn, $sql)) {
      echo "<p style='color:green;'>Student added successfully!</p>";
    } else {
      echo "<p style='color:red;'>Error: " . mysqli_error($conn) . "</p>";
    }
  }
  ?>
  <br><a href="index.php">← Back to Home</a>
</body>
</html>